`pragma protect begin_protected
`pragma protect version="1.0"
`pragma protect author="default"
`pragma protect author_info="default"
`pragma protect encrypt_agent="GOWIN"
`pragma protect encrypt_agent_info="GOWIN Encrypt Version 1.0"

`pragma protect encoding=(enctype="base64", line_length=76, bytes=256)
`pragma protect key_keyowner="GOWIN",key_keyname="GWK2022-11",key_method="rsa"
`pragma protect key_block
BN6yIBAi0gFlkDHg/uZqAxU2eDIvtqgjYVULQLUjk9Nqcf1HY7jjL1+cn9vBd9icIakCR5mdJg06
QZXDZkT8mqbuz1w6NwWSQzat3h3GqZKL5CTZl9dUlpFxTepTzhAeR7zWprfdDgSBaI+x5uuGwwFL
eGb9vQY1sOt1z5wqmlxW8UiiR7rmJWECmHZh6UcI1GaPnk75/00kbbn9HJ2Ym9w8NiO9ObG+vnB7
sz2VUPvoHC9S95wL+bxGor5MeObNog4FoEy+Km12hQN+uWPBlnoOKDIBAeYjwVUpWHxz40kjjvF0
jP/lnxoa1+1ynfxXdQx68M+pAZceuDK7B6k3Nw==

`pragma protect encoding=(enctype="base64", line_length=76, bytes=624)
`pragma protect data_keyowner="default-ip-vendor"
`pragma protect data_keyname="default-ip-key"
`pragma protect data_method="aes128-cbc"
`pragma protect data_block
neqqIYYrMuxD3aBXIC07Im2QVpgp/KN5eHenL33sif2iKBToZHOgQYluiV3z/qRGEkyVMegtkzB1
y2IVpjEOEReRaRUIPp5bo5nd1++h1AWM96jbF+M37CcKITgaWV3RBUmIaQNxSP/zc1OmRbZRPSyd
rSxNugY50ohqOTETT9gm70LCd6mq0TVCOq6FWzTkgBNqjpYTJaTnYuHgQPkdscrXLFEmRRRE37Gk
v8zWjEL9xjr2bwztO3TBHDD/hT8j6nOP/jeEvs3NP8BwgO1AnstsMxhLw8yiaISQ8cuH/4ADVyyo
L2Dj7ThN2K/Hlvdxm9GaV18ByP1nuZixU/gVIhz2pztWub9hW50tt6znAMvFRGIixuUKsCUgeBqW
1bEtmu2msR3elpFh5wisD0X8uHDTpD+l2n2M0yZF9eooydRBQr3wEQa/Glql5WMPNi82VmaY9gPh
+bdXhmfdCd3O7lr5IX1toWWsx5CykudEwHCSZpPSEiI/RkX3R+FBoD8bsxRFdhykn/rp6EOS9vdq
tPdwkxtaKoAO6RvgNOE8Hl4MJ1zZ589MBNovVMHH02zMPLPXaRgkDmZWU/9nHb88Hz6tHrfo/kDr
XMNYzbC0him5uMtrKYcpS7eNkX4sliAW72bqO51cn56Mm42JR07RpiEK/TmzZkJh5JlamHr+DmMU
CI9BuaFMA810o7A7rOOVAURURxq7KvNusjmwSjiQgrEfcaeKog3IRihFb/ZI84ZRu9/AhMQzHsMr
ZPut1rrD/aoV1dqh4xvD5FnO/ieZw108mDSiV5HGUBhN2txzgtydl43TkBorlKNwsF4PjcjC
`pragma protect end_protected

`pragma protect begin_protected
`pragma protect version="1.0"
`pragma protect author="default"
`pragma protect author_info="default"
`pragma protect encrypt_agent="GOWIN"
`pragma protect encrypt_agent_info="GOWIN Encrypt Version 1.0"

`pragma protect encoding=(enctype="base64", line_length=76, bytes=256)
`pragma protect key_keyowner="GOWIN",key_keyname="GWK2022-11",key_method="rsa"
`pragma protect key_block
X2pSJEopBWdH/7K1fiMhFRRUdqnRYFPOOC8g8q9jeNG8iqO3N5De1G+DutwRI/BzIXkjhoffqNJJ
Y4uRhrZoe72VljPCzeeAg0G/MmSx685WOIPyGIzqVhkS8Il38gEpZvlDR3FW73N7OY7ywuw1QqH/
WmvV+85u7lRmYxFQJ4kFPH9zMNQ2WqZ8fC/KiYmKWuxene6d6TnBg7uZMSNV2DHQzA+suv0SePMy
TDy4hg/HhEbB9g3MaKk2UpzEKOsAERCumuptiOxbFVHxnaGmvCpoKDSCQ9N/414yg5+rGGBOuwRG
DG7OLWkU+xOZ7FQYGya8s7/sh2vmhYT3awhOjw==

`pragma protect encoding=(enctype="base64", line_length=76, bytes=1952)
`pragma protect data_keyowner="default-ip-vendor"
`pragma protect data_keyname="default-ip-key"
`pragma protect data_method="aes128-cbc"
`pragma protect data_block
neqqIYYrMuxD3aBXIC07Iq0iBugwUZaeHyYK8rndgHPKb2DlRdP+r5JF/co1Noc7SdAH+OvRcIX8
0bTl7Ful3unF76+r7abVz33GAFZdT7VoVCj4PCwRGv6b2bfZGQJGGTw4ZTa+EGPUi9KvQJbGiL+g
7PUrqBHVFOt3fdhc1cVE2qmz4sG9mmBTX/y2LJD8GJcrMzuXVMNBm1+cj1OaIWkIBN0JU9KfqRdA
sSxMkgDoliKxMrEGoUBM9pVG3mOXX25WtiCWUTAH0leVpGuzY2rULxEn9k8vvtlsnItqYE+bq5GA
9yFG4wGLHU7TsMQ6s9FbwwLbMM2eBDsjFTWqU5ukGueW/RzXPo6H+ZIoyiNKDAH+WFXmtIWqPneS
kr8OeStoJI0HYT9laE6dufoEBeWp21qnmMLbtsERJXak/OcoHG3LiuohMaq4dLYAvFnNXT0FFTVG
I5agBOjenQj6OIRLw+YfgZeTDx0oupdKo4Yht5an+Yz9LYnzxso7xXFJmTONw3e7v4YIJFdWzzzo
0E1mX4ZTWes135T4W9oUUd9Ya5pINEI+zwe+kiqiry4A3xQnUev8RGs48Wnmhj62t0083PbE3e12
nMZUzbGeZ9Pyvgwppi9eKWSIPwnTHn5kBVWgbfe5TU4uUOWf38+wqUgSmyAmqCIR7rX3P4MwvIpC
jyWKkYf8PE6ASUQo1/Sjz6jpgeXAiVSEy9JlB2VHhJIXDiBaUvcZ21eKWDXpT28DYjOxKxOw6jqi
aJOZSFRLRqlyujeTj/TUFni+fpx2pRAJBHN9fAg5LAPo4/zmBbXlyNnDhGzxYcfVXGisg9a4+wcA
98aJ7RFYmUmcMJdcFWE1PiP8xGek9NfMU+YLvxvRD62GK7lsx9vt9MtJnB4zKlxKFdnI/SCCkttt
2+++osbmRoZq141OKeo7lAcSkMa4PI9LHr7U8jUePXBvpI/2M7Hyra6v/PBt5nowlDePN+7E/0kd
ludshab8IdjVxZugAbf0eR2wkKzIlzWKyRLePX6gKYwfDnkCGStCGS1RsPk6jMs5Dq+LMX6k7zcy
uPUe+NfXWvnzHY/iXlrTY3SStmkbcsEhEpXrTnwLr3yJMejTlLGu9zKfbHxE/pBPXFvxE/o9U6ju
wAF07gDpyu7RbbphTMmfbksx6L9Tn1IlkEzMFGC7wNEyxyUatT+LiICipdXlhRxs7ySH7oZli/rO
QkDLRrYBgXOOcJUUsENrupDUWhP+ay69+XHVqfLQdm6MfWZotHZ/qnValEIpeql8T6bcRsLOu9VV
O6qT8Q7IBHRxkk0/I/vAX4yoPuSSvaI97rX8DF7fJjrSrlqqShCRg2TDSV/QNeTfV5RpcWNgdmeJ
TsQyRu5qBzqTKQRJAM4=KDFEfX2n/tcMxW0EWQEsy7mUHTCTlwJwm6ZAywCsmRr+kqDiaS/dvpUX
cUE44Lx7F+gabg5nfOQpHw53MLHdF7wiDgBcKuhCL7eU+y0UTfi36f8K8IpAIO2CVjZ282aLEFIP
GfaVfSi6OdKRX1wHWsXBn7T9IByWIs4zoyaN45Lae8UXXtXadc8ObJXyxZDe1XBeibeox+tFCOIa
JRnzGqo+1/5Ypl8X4EaJficglqfUPtUGG2nsw8Ml1p2+rZ1B1Zct1WbxZ8Ex5/b/2JcNz506X9KP
aPJWDx20byB5V1/lgUICpWxhpH1NgPDqzsb8P+vDwxvK37VQ5O3hkjc7PlqNPZ2JU9KUuo0/advH
JDih2A+s8igpCe9Jr7TQ/z9AHwSOnoIkX/AnzP2IfjSmhckR01v5K5YlvmG7qQje7MTmg5OoJrbl
mVzuhVkihf8FP00kykraZ7Qnt+AnkbG64dncTTQbfdeh/hrH6z0mlN2eglo0t7+Jh67n4NskojcX
01Yad07C1VHmii2FVgxYuk+2EMnADKoe3TMfe0+bQRdDxHN51YSw17eSW5T8f4TJfLFzIwBPoh83
UAuKAuW1AZQtfi38nsd0WUEcjKRntVjAJsYD4VPKBZoJBjuVJJ5hzfohS0fryLqxKehqsQAPhPKm
+0rQzj4rTOVj6jzdsSd1ITkpPDNBxDUNgDDwSI2wev+s3HFvRlF7POmoPhIyn1TmUf1nTYLD+a+c
kPFW8uQSG7NkcFaoSrQYOFRFFQpooYLyRQk2W3bhE/VMBahknzCadUZ0gEdu/qPCn6M9+bRaa14t
eOjpNRkwj3+DF+DeuLLLaapk2wMXevux0nM54qx/Bs6ygnfnpwW3hOXkfum95kGNGCjmrZhX+VSu
6P2kRjk9QrVKhCsfzSZRisxWXtlT1b9vBeCg7pPFRv6fb/BIaxcNIieD5IG+H0+st6eHSW7DBa7B
FqmnM/15yAY3uW5uIWLoPuxv5eQyJPn7aiuTchZM0tc6CN/+GY1NlkS3fCDUzz/kBfKD1SVBwWhk
+4VsiRFRoiHR5GfWY54B/n4ZjmrJ/9QCI9IBjqMdcZ+xlCtgc3nVvQnAG6xJ2PgHmFvNIARosd0d
NtZFzycQy9fC+CTukOvzFqMvC5wVFJ38KBVPLO1PMmaEqPl3STBojfuHFO4Lvq2Hy0ufL525Gg9w
CiV3uKU/ScAwJAiDLGqe
`pragma protect end_protected

`pragma protect begin_protected
`pragma protect version="1.0"
`pragma protect author="default"
`pragma protect author_info="default"
`pragma protect encrypt_agent="GOWIN"
`pragma protect encrypt_agent_info="GOWIN Encrypt Version 1.0"

`pragma protect encoding=(enctype="base64", line_length=76, bytes=256)
`pragma protect key_keyowner="GOWIN",key_keyname="GWK2022-11",key_method="rsa"
`pragma protect key_block
qjUq3t4wedvT17XTmj3w2YeEF/zZ07NkHXCvH0fBRIZpCOXaC59/r/ugNMqkdtt3n7H7uGBfaFaE
7OzMy2eQ/VzFU4atpA5czSncv9jgtIIK8QBkJ1L+j5Lf+lAf/B19pgyFQKjZ1yJMjPAN6fvo3Tj1
kS7evxMfMD/qhEWMoLEgJFJNhSamwBkFWILZX8XEp6j5ZdccYvkuEOtZl3i3DqWsQzGGS1mEHBCa
Qe0+UdiQVWoZxEmgI+4jgcOcQ2cTlx2stma3LCJGerkMVgPIiwWi5iZSNaSx02ongosb6s9w3P4M
jK6FLpelGJr2vlZini784G5J5GGzbam6uPP5lg==

`pragma protect encoding=(enctype="base64", line_length=76, bytes=272)
`pragma protect data_keyowner="default-ip-vendor"
`pragma protect data_keyname="default-ip-key"
`pragma protect data_method="aes128-cbc"
`pragma protect data_block
neqqIYYrMuxD3aBXIC07IruXYLkaqQvpBIO8cSH9fE9NRpuo9z1tL3rlDfrHQdFmSTM+bkvaE55i
AxOrYAAAaldsc+TYXxxEYBiHHKv9eer9+ZlYU2gO4N3yIWhiVs0XC4dRmvzGF3C1KIol1brv4vGa
9eB06AF0sW1ITBam4ZIgGJbSE1bIEv0rjaL8DrNE7FTXlimBnTsXxmAGEK14HlYDb2ZIS64dTO+j
yO147MIAhfxpu5O3i0C1KR4YSu4/RsHoLYqGrpM89rhEKRSbRnWep6fHV0w3tZuqWxYUhHQT4AgV
/U/TLnoRCO8SdVk+P3WzjDeY8hObINIeHqL20l7Ot8QApq6Tl7qJoQttN3E=
`pragma protect end_protected
